 class _Main {
     static function main(args : string[]) : void {
         log "Hello World";
     }
 }
