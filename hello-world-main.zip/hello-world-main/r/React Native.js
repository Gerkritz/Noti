import React from "react";
import { Text, View } from "react-native";

export default function HelloWorld() {
    return (
        <View>
            <Text>Hello World</Text>
        </View>
    );
}
