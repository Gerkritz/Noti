لکھو ("Hello World")
