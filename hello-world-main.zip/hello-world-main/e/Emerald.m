const main <- object mainProgram
    initially
		stdout.putString["Hello World\n"]
	end initially
end mainProgram