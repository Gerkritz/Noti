#!/usr/bin/env elixir
IO.puts "Hello World"
