Module HelloWorld
    Sub Main()
        MsgBox("Hello World")
    End Sub
End Module