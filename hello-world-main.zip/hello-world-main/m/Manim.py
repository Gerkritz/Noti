from manim import *

class HelloWorld(Scene):
  def construct(self):
    self.add(Text("Hello World"))
