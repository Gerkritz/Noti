SELECT 'Hello World' FROM DUAL;
